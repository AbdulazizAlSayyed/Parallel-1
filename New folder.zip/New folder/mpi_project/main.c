#include <mpi.h>
#include <stdio.h>
#include <math.h>

// Function to evaluate the curve (y = f(x))
double fn(double x) {
    return x * x; // example: y = x^2
}

// Function to compute the area of a trapezoid
double trapezoid_area(double a, double b, double d) { 
    double area = 0.0;
    for (double x = a; x < b; x += d) {
        area += fn(x) + fn(x + d);
    }
    return area * d / 2.0;
}

int main(int argc, char** argv) {
    int rank, size;
    double a = 0.0, b = 1.0;
    int nb;
    double start, end, local_area, total_area;

    // Assume the number of intervals is given
    nb = 10000000;
    double d = (b - a) / nb; // delta (width of each subinterval)

    // Sequential time tracking
    double sequential_start, sequential_end, sequential_time;
    double sequential_area = 0.0;

    // Parallel time tracking
    double parallel_start, parallel_end, parallel_time;

    // Initialize MPI
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); // Get rank of the process
    MPI_Comm_size(MPI_COMM_WORLD, &size); // Get number of processes

    if (rank == 0) {
        printf("The number of intervals is: %d \n", nb);

        // Sequential implementation
        sequential_start = MPI_Wtime();
        sequential_area = trapezoid_area(a, b, d);
        sequential_end = MPI_Wtime();

        sequential_time = sequential_end - sequential_start;

        printf("\n..Sequential Results..\n");
        printf("The total area under the curve is: %f\n", sequential_area);
        printf("The time it took to complete the operation is: %f seconds\n", sequential_time);
    }

    parallel_start = MPI_Wtime();

    // Broadcast the number of intervals to all the processes
    MPI_Bcast(&nb, 1, MPI_INT, 0, MPI_COMM_WORLD);

    // Calculate the region for each process
    double region = (b - a) / size;

    // Calculate the local bounds for each process
    start = a + rank * region;
    end = start + region;

    // Each process calculates the area of its subinterval
    local_area = trapezoid_area(start, end, d);

    // Ensure all processes reach this point before reduction
    MPI_Barrier(MPI_COMM_WORLD);

    // Reduce all local areas to the total area on the root process
    MPI_Reduce(&local_area, &total_area, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    parallel_end = MPI_Wtime();
    parallel_time = parallel_end - parallel_start;

    if (rank == 0) {
        printf("\n..Parallel Results..\n");
        printf("The total area under the curve is: %f\n", total_area);
        printf("The time it took to complete the operation is: %f seconds\n", parallel_time);

        // Calculate speedup and efficiency
        double speedUp = sequential_time / parallel_time;
        printf("The speedup factor is: %f\n", speedUp);
        printf("The efficiency is: %f%%\n", (speedUp / size) * 100);
    }

    // Finalize MPI
    MPI_Finalize();

    return 0;
}