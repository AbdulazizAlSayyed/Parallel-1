#include <mpi.h>
#include <stdio.h>
#include <math.h>

// Function to evaluate the curve (y = f(x))
double compute_curve(double x_value) {
    return x_value * x_value; // example: y = x^2
}

// Function to compute the area of a trapezoid
double calculate_trapezoid_area(double lower_bound, double upper_bound, double step_size) { 
    double trapezoid_area = 0.0;
    for (double current_x = lower_bound; current_x < upper_bound; current_x += step_size) {
        trapezoid_area += compute_curve(current_x) + compute_curve(current_x + step_size);
    }
    return trapezoid_area * step_size / 2.0;
}

int main(int num_arguments, char** argument_values) {
    int process_rank, total_processes;
    double lower_limit = 0.0, upper_limit = 1.0;
    int num_intervals;
    double local_start, local_end, local_trapezoid_area, global_trapezoid_area;

    // Assume the number of intervals is given
    num_intervals = 10000000;
    double step_delta = (upper_limit - lower_limit) / num_intervals; // delta (width of each subinterval)

    // Sequential time tracking
    double sequential_start_time, sequential_end_time, sequential_duration;
    double sequential_trapezoid_area = 0.0;

    // Parallel time tracking
    double parallel_start_time, parallel_end_time, parallel_duration;

    // Initialize MPI
    MPI_Init(&num_arguments, &argument_values);
    MPI_Comm_rank(MPI_COMM_WORLD, &process_rank); // Get rank of the process
    MPI_Comm_size(MPI_COMM_WORLD, &total_processes); // Get number of processes

    if (process_rank == 0) {
        printf("The number of intervals is: %d \n", num_intervals);

        // Sequential implementation
        sequential_start_time = MPI_Wtime();
        sequential_trapezoid_area = calculate_trapezoid_area(lower_limit, upper_limit, step_delta);
        sequential_end_time = MPI_Wtime();

        sequential_duration = sequential_end_time - sequential_start_time;

        printf("\n..Sequential Results..\n");
        printf("The total area under the curve is: %f\n", sequential_trapezoid_area);
        printf("The time it took to complete the operation is: %f seconds\n", sequential_duration);
    }

    parallel_start_time = MPI_Wtime();

    // Broadcast the number of intervals to all the processes
    MPI_Bcast(&num_intervals, 1, MPI_INT, 0, MPI_COMM_WORLD);

    // Calculate the region for each process
    double process_region = (upper_limit - lower_limit) / total_processes;

    // Calculate the local bounds for each process
    local_start = lower_limit + process_rank * process_region;
    local_end = local_start + process_region;

    // Each process calculates the area of its subinterval
    local_trapezoid_area = calculate_trapezoid_area(local_start, local_end, step_delta);

    // Ensure all processes reach this point before reduction
    MPI_Barrier(MPI_COMM_WORLD);

    // Reduce all local areas to the total area on the root process
    MPI_Reduce(&local_trapezoid_area, &global_trapezoid_area, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    parallel_end_time = MPI_Wtime();
    parallel_duration = parallel_end_time - parallel_start_time;

    if (process_rank == 0) {
        printf("\n..Parallel Results..\n");
        printf("The total area under the curve is: %f\n", global_trapezoid_area);
        printf("The time it took to complete the operation is: %f seconds\n", parallel_duration);

        // Calculate speedup and efficiency
        double speed_up_factor = sequential_duration / parallel_duration;
        printf("The speedup factor is: %f\n", speed_up_factor);
        printf("The efficiency is: %f%%\n", (speed_up_factor / total_processes) * 100);
    }

    // Finalize MPI
    MPI_Finalize();

    return 0;
}
